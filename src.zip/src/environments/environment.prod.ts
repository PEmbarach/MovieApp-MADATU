export const environment = {
  production: true,
  apiKey: '72ca25be1e43b8a3728cc4a28d7d34b4',
  apiBaseUrl: 'https://api.themoviedb.org/3',
  apiImageUrl: 'https://image.tmdb.org/t/p/w500'
};
